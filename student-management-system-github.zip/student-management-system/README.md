# Student Management System

A beginner-friendly full-stack Student Management System built with Java, Spring Boot MVC, JDBC, MySQL, HTML, CSS and JavaScript.

## Features

- Add student
- View all students
- Edit student
- Delete student
- REST API
- MySQL database
- JDBC database access
- Server-side validation
- Responsive frontend
- Maven dependency management

## Technologies

- Java 17
- Spring Boot
- Spring Web
- Spring JDBC
- MySQL
- MySQL Connector/J
- Maven
- HTML5
- CSS3
- JavaScript
- Git/GitHub

## Project Structure

```text
student-management-system/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/student/
│       │   ├── controller/
│       │   ├── model/
│       │   ├── repository/
│       │   ├── service/
│       │   └── StudentApplication.java
│       └── resources/application.properties
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── database/
│   └── student_db.sql
└── README.md
```

## Requirements

Install:

1. JDK 17 or newer
2. Maven
3. MySQL or XAMPP
4. VS Code / IntelliJ IDEA / Eclipse
5. Git

## Database Setup

Start MySQL.

Open phpMyAdmin or MySQL command line and run:

```sql
SOURCE database/student_db.sql;
```

Or copy and run the contents of `database/student_db.sql`.

Default local configuration in this project:

```text
Database: student_db
Username: root
Password: empty
Host: localhost
Port: 3306
```

If your MySQL username/password is different, edit:

```text
backend/src/main/resources/application.properties
```

## Run the Backend

Open a terminal:

```bash
cd backend
mvn spring-boot:run
```

The API will run at:

```text
http://localhost:8080
```

Test the API:

```text
GET http://localhost:8080/api/students
```

## Run the Frontend

After starting the backend, open:

```text
frontend/index.html
```

You can use VS Code with the Live Server extension, or open the HTML file in a browser.

The frontend communicates with:

```text
http://localhost:8080/api/students
```

## REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | Get all students |
| GET | `/api/students/{id}` | Get one student |
| POST | `/api/students` | Add student |
| PUT | `/api/students/{id}` | Update student |
| DELETE | `/api/students/{id}` | Delete student |

### Example POST JSON

```json
{
  "name": "Hareeshwar",
  "email": "hareeshwar@example.com",
  "age": 20,
  "course": "Computer Science"
}
```

## Architecture

```text
HTML/CSS/JavaScript
        |
        | HTTP / JSON
        v
Spring Boot Controller
        |
        v
Service Layer
        |
        v
Repository / JdbcTemplate
        |
        v
MySQL Database
```

## Upload to GitHub

Create a new repository on GitHub, for example:

```text
student-management-system
```

Then from the project root:

```bash
git init
git add .
git commit -m "Initial Student Management System"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do not commit database passwords or other secrets to GitHub.

## Learning Outcomes

This project demonstrates:

- Java OOP
- MVC architecture
- REST APIs
- JDBC
- SQL
- MySQL
- Spring Boot
- Dependency management with Maven
- Frontend/backend communication
- CRUD operations
- Git and GitHub

## Future Improvements

- Login and authentication
- Role-based authorization
- Pagination
- Search and filtering
- Dashboard
- Better exception handling
- Unit and integration tests
- Deployment
