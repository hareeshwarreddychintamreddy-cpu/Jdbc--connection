const API_URL = "http://localhost:8080/api/students";

const form = document.getElementById("studentForm");
const message = document.getElementById("message");

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const id = document.getElementById("studentId").value;

    const student = {
        name: document.getElementById("name").value.trim(),
        email: document.getElementById("email").value.trim(),
        age: Number(document.getElementById("age").value),
        course: document.getElementById("course").value.trim()
    };

    try {
        const response = await fetch(id ? `${API_URL}/${id}` : API_URL, {
            method: id ? "PUT" : "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(student)
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            throw new Error(error.message || "Request failed");
        }

        showMessage(id ? "Student updated successfully." : "Student added successfully.");
        resetForm();
        loadStudents();

    } catch (error) {
        showMessage(error.message, true);
    }
});

async function loadStudents() {
    const table = document.getElementById("studentTable");
    table.innerHTML = "<tr><td colspan='6'>Loading...</td></tr>";

    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("Could not load students.");
        }

        const students = await response.json();

        if (students.length === 0) {
            table.innerHTML = "<tr><td colspan='6'>No students found.</td></tr>";
            return;
        }

        table.innerHTML = students.map(student => `
            <tr>
                <td>${student.id}</td>
                <td>${escapeHtml(student.name)}</td>
                <td>${escapeHtml(student.email)}</td>
                <td>${student.age}</td>
                <td>${escapeHtml(student.course)}</td>
                <td>
                    <button onclick="editStudent(${student.id})">Edit</button>
                    <button class="delete" onclick="deleteStudent(${student.id})">
                        Delete
                    </button>
                </td>
            </tr>
        `).join("");

    } catch (error) {
        table.innerHTML =
            `<tr><td colspan="6">${escapeHtml(error.message)}</td></tr>`;
    }
}

async function editStudent(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`);

        if (!response.ok) {
            throw new Error("Student not found.");
        }

        const student = await response.json();

        document.getElementById("studentId").value = student.id;
        document.getElementById("name").value = student.name;
        document.getElementById("email").value = student.email;
        document.getElementById("age").value = student.age;
        document.getElementById("course").value = student.course;

        document.getElementById("formTitle").textContent = "Edit Student";
        window.scrollTo({ top: 0, behavior: "smooth" });

    } catch (error) {
        showMessage(error.message, true);
    }
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: "DELETE"
        });

        if (!response.ok) {
            throw new Error("Could not delete student.");
        }

        showMessage("Student deleted successfully.");
        loadStudents();

    } catch (error) {
        showMessage(error.message, true);
    }
}

function resetForm() {
    form.reset();
    document.getElementById("studentId").value = "";
    document.getElementById("formTitle").textContent = "Add Student";
}

function showMessage(text, error = false) {
    message.textContent = text;
    message.style.color = error ? "#dc2626" : "#15803d";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadStudents();
