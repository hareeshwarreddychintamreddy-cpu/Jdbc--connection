package com.example.student.repository;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Student save(Student student) {
        String sql = "INSERT INTO students(name, email, age, course) VALUES (?, ?, ?, ?)";

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setInt(3, student.getAge());
            ps.setString(4, student.getCourse());
            return ps;
        }, keyHolder);

        student.setId(keyHolder.getKey().longValue());
        return student;
    }

    public List<Student> findAll() {
        String sql = "SELECT id, name, email, age, course FROM students ORDER BY id DESC";

        return jdbcTemplate.query(sql, (rs, rowNum) ->
                new Student(
                        rs.getLong("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getInt("age"),
                        rs.getString("course")
                ));
    }

    public Student findById(Long id) {
        String sql = "SELECT id, name, email, age, course FROM students WHERE id = ?";

        List<Student> students = jdbcTemplate.query(sql, (rs, rowNum) ->
                new Student(
                        rs.getLong("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getInt("age"),
                        rs.getString("course")
                ), id);

        return students.isEmpty() ? null : students.get(0);
    }

    public int update(Long id, Student student) {
        String sql = "UPDATE students SET name = ?, email = ?, age = ?, course = ? WHERE id = ?";

        return jdbcTemplate.update(
                sql,
                student.getName(),
                student.getEmail(),
                student.getAge(),
                student.getCourse(),
                id
        );
    }

    public int delete(Long id) {
        return jdbcTemplate.update("DELETE FROM students WHERE id = ?", id);
    }
}
