package com.example.studentapp.repository;

import com.example.studentapp.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

// Spring generates all the database code (save, findAll, deleteById...) for you
public interface StudentRepository extends JpaRepository<Student, Long> {
}
