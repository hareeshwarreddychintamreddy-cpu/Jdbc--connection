# Student App (Java MVC + Spring Boot)

A simple CRUD web app that demonstrates the MVC pattern:

- **Model**: `Student` entity (JPA)
- **View**: Thymeleaf HTML templates
- **Controller**: `StudentController`
- **Database**: H2 by default, MySQL optional

## Requirements
- Java 17+
- Maven 3.8+

## Run
```bash
mvn spring-boot:run
```
Open http://localhost:8080

## Use MySQL
1. Create a database: `CREATE DATABASE studentdb;`
2. Edit `src/main/resources/application.properties` (follow the comments).
3. Set environment variables `DB_USERNAME` and `DB_PASSWORD` (never commit passwords).

## Project structure
```
src/main/java/com/example/studentapp
 ├── StudentAppApplication.java
 ├── controller/StudentController.java
 ├── model/Student.java
 └── repository/StudentRepository.java
src/main/resources
 ├── application.properties
 └── templates/ (students.html, student-form.html)
```
